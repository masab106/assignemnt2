require 'test_helper'

class JugnusControllerTest < ActionController::TestCase
  setup do
    @jugnu = jugnus(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:jugnus)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create jugnu" do
    assert_difference('Jugnu.count') do
      post :create, jugnu: { address: @jugnu.address, name: @jugnu.name }
    end

    assert_redirected_to jugnu_path(assigns(:jugnu))
  end

  test "should show jugnu" do
    get :show, id: @jugnu
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @jugnu
    assert_response :success
  end

  test "should update jugnu" do
    patch :update, id: @jugnu, jugnu: { address: @jugnu.address, name: @jugnu.name }
    assert_redirected_to jugnu_path(assigns(:jugnu))
  end

  test "should destroy jugnu" do
    assert_difference('Jugnu.count', -1) do
      delete :destroy, id: @jugnu
    end

    assert_redirected_to jugnus_path
  end
end
