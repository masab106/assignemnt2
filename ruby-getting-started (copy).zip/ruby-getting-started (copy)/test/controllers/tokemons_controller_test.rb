require 'test_helper'

class TokemonsControllerTest < ActionController::TestCase
  setup do
    @tokemon = tokemons(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:tokemons)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create tokemon" do
    assert_difference('Tokemon.count') do
      post :create, tokemon: { electrify: @tokemon.electrify, fight: @tokemon.fight, fire: @tokemon.fire, fly: @tokemon.fly, height: @tokemon.height, ice: @tokemon.ice, name: @tokemon.name, total: @tokemon.total, trainer_id: @tokemon.trainer_id, water: @tokemon.water, weight: @tokemon.weight }
    end

    assert_redirected_to tokemon_path(assigns(:tokemon))
  end

  test "should show tokemon" do
    get :show, id: @tokemon
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @tokemon
    assert_response :success
  end

  test "should update tokemon" do
    patch :update, id: @tokemon, tokemon: { electrify: @tokemon.electrify, fight: @tokemon.fight, fire: @tokemon.fire, fly: @tokemon.fly, height: @tokemon.height, ice: @tokemon.ice, name: @tokemon.name, total: @tokemon.total, trainer_id: @tokemon.trainer_id, water: @tokemon.water, weight: @tokemon.weight }
    assert_redirected_to tokemon_path(assigns(:tokemon))
  end

  test "should destroy tokemon" do
    assert_difference('Tokemon.count', -1) do
      delete :destroy, id: @tokemon
    end

    assert_redirected_to tokemons_path
  end
end
