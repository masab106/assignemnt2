require 'test_helper'

class TokemonTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
