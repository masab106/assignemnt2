class Thing < ActiveRecord::Base
  belongs_to :person
end
