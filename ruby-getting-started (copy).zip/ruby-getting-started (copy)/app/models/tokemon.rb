class Tokemon < ActiveRecord::Base
  belongs_to :trainer
