class Person < ActiveRecord::Base
  has_many :things
end
