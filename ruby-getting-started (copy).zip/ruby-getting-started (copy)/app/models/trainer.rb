class Trainer < ActiveRecord::Base
  has_many :tokemons
end
