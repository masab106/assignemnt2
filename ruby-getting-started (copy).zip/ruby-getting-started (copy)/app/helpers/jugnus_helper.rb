module JugnusHelper
end
