class TokemonsController < ApplicationController
  before_action :set_tokemon, only: [:show, :edit, :update, :destroy]

  # GET /tokemons
  # GET /tokemons.json
  def index
    @tokemons = Tokemon.all
  end

  # GET /tokemons/1
  # GET /tokemons/1.json
  def show
  end

  # GET /tokemons/new
  def new
    @tokemon = Tokemon.new
  end

  # GET /tokemons/1/edit
  def edit
  end

  # POST /tokemons
  # POST /tokemons.json
  def create
    @tokemon = Tokemon.new(tokemon_params)

    respond_to do |format|
      if @tokemon.save
        format.html { redirect_to @tokemon, notice: 'Tokemon was successfully created.' }
        format.json { render :show, status: :created, location: @tokemon }
      else
        format.html { render :new }
        format.json { render json: @tokemon.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /tokemons/1
  # PATCH/PUT /tokemons/1.json
  def update
    respond_to do |format|
      if @tokemon.update(tokemon_params)
        format.html { redirect_to @tokemon, notice: 'Tokemon was successfully updated.' }
        format.json { render :show, status: :ok, location: @tokemon }
      else
        format.html { render :edit }
        format.json { render json: @tokemon.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /tokemons/1
  # DELETE /tokemons/1.json
  def destroy
    @tokemon.destroy
    respond_to do |format|
      format.html { redirect_to tokemons_url, notice: 'Tokemon was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_tokemon
      @tokemon = Tokemon.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def tokemon_params
      params.require(:tokemon).permit(:name, :weight, :height, :fly, :fight, :fire, :water, :electrify, :ice, :total, :trainer_id)
    end
end
