class JugnusController < ApplicationController
  before_action :set_jugnu, only: [:show, :edit, :update, :destroy]

  # GET /jugnus
  # GET /jugnus.json
  def index
    @jugnus = Jugnu.all
  end

  # GET /jugnus/1
  # GET /jugnus/1.json
  def show
  end

  # GET /jugnus/new
  def new
    @jugnu = Jugnu.new
  end

  # GET /jugnus/1/edit
  def edit
  end

  # POST /jugnus
  # POST /jugnus.json
  def create
    @jugnu = Jugnu.new(jugnu_params)

    respond_to do |format|
      if @jugnu.save
        format.html { redirect_to @jugnu, notice: 'Jugnu was successfully created.' }
        format.json { render :show, status: :created, location: @jugnu }
      else
        format.html { render :new }
        format.json { render json: @jugnu.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /jugnus/1
  # PATCH/PUT /jugnus/1.json
  def update
    respond_to do |format|
      if @jugnu.update(jugnu_params)
        format.html { redirect_to @jugnu, notice: 'Jugnu was successfully updated.' }
        format.json { render :show, status: :ok, location: @jugnu }
      else
        format.html { render :edit }
        format.json { render json: @jugnu.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /jugnus/1
  # DELETE /jugnus/1.json
  def destroy
    @jugnu.destroy
    respond_to do |format|
      format.html { redirect_to jugnus_url, notice: 'Jugnu was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_jugnu
      @jugnu = Jugnu.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def jugnu_params
      params.require(:jugnu).permit(:name, :address)
    end
end
