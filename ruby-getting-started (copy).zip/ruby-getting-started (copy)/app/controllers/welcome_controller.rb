class WelcomeController < ApplicationController

  # GET /welcome
  def index

  end

end
